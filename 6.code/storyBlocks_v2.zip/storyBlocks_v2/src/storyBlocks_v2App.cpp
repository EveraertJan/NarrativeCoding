#include "cinder/app/AppNative.h"
#include "cinder/gl/gl.h"
#include "cinder/Utilities.h"
#include "cinder/gl/Fbo.h"

using namespace ci;
using namespace ci::app;
using namespace std;


#include "UI.h"
#include "Track.h"
#include "Cam.h"
#include "Story.h"

class storyBlocks_v2App : public AppNative {
  public:
	void setup();
	void mouseDown( MouseEvent event );	
	void update();
	void draw();
    
    
    
    int state;
    
    UI ui;
    Track track;
    Cam cam;
    Story story;
    
    
    
};
void storyBlocks_v2App::setup(){
    setWindowSize(1400, 900);
    //setFullScreen(true);
    setWindowPos(0, 0);
    state = 0;
    cam.setup();
}
void storyBlocks_v2App::update(){
    cam.update();
}
void storyBlocks_v2App::draw(){
    
	// clear out the window with black
	gl::clear( Color( 0, 0, 0 ) );
    cam.draw();
    
    Surface w = copyWindowSurface();
    switch(state){
        {case 0:
            ci::Area sa = ui.showBookScan();
            
            if(track.trackcode(w.clone(sa), sa.getUL(),  true) == 1552){
                if(story.loadStory(1552)){
                    state++;
                } else {
                    ci::app::console() << "couldn't load \n";
                }
            }
            //scan book when completed
            break;}
        case 1:
            //green card situation;
            if(track.greenScan(w.clone(ui.showGreenCard()))){
                state++;
            }
            break;
        case 2:
            ui.tutorial();
            if(track.greenScan(w.clone(ui.showGreenCard()))){
                state++;
            }
            track.tagPos.clear();
            // codeBlock, show ui
            break;
        {case 3:
            ci::Area sa = ui.TagScan();
            track.trackcode(w.clone(sa), sa.getUL(), false);
            track.followTags(w);
            ui.showTagConnections(track.tagPos);
            // codeBlock, add tags
            break;}
        case 4:
            // compile
            break;
        case 5:
            // display output
            break;
        case 6:
            // show results
            break;
            
    }
    if(state>0) {
        track.trackBook(w);
    }
    
    
    gl::color(255, 0, 0);
    gl::drawString(toString(state), Vec2i(10, 10));
    
    
}
void storyBlocks_v2App::mouseDown( MouseEvent event ){
    
}

CINDER_APP_NATIVE( storyBlocks_v2App, RendererGl )
